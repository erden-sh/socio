---
name: weekly-report
description: Write the weekly team report
---
1. Collect wins, risks and next steps.
2. Keep it under 200 words.
